import MovieListPage from "./MovieListPage";
import VideoPlayerPage from "./VideoPlayerPage";
export { MovieListPage, VideoPlayerPage };
