import VideoPage from "../Spinner/VideoPage";

const VideoPlayerPage = () => {
  console.log();
  return (
    <>
      <VideoPage />
    </>
  );
};

export default VideoPlayerPage;
