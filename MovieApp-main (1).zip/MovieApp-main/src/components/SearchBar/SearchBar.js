const SearchBar = () => {};

export default SearchBar;
